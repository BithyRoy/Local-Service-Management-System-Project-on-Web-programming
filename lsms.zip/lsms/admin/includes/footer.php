<footer class="main-footer">
    <strong>Copyright &copy; <?= date("Y") ?></strong>
    Local Service Management System
    
  </footer>